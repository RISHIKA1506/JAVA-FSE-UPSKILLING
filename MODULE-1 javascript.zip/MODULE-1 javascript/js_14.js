// script.js
$(document).ready(function () {
  // Handle click event using jQuery
  $('#registerBtn').click(function () {
    // Toggle event cards using fadeIn/fadeOut
    $('.event-card').each(function () {
      if ($(this).is(':visible')) {
        $(this).fadeOut(500);
      } else {
        $(this).fadeIn(500);
      }
    });
  });
});
