// Log a welcome message in the browser console
console.log("Welcome to the Community Portal");

// Show an alert when the page is fully loaded
window.onload = function() {
  alert("Page fully loaded. Welcome to the Community Portal!");
};
