console.log("Welcome to the Community Portal (Task 5)");

// Event class
class Event {
  constructor(name, date, category, seats) {
    this.name = name;
    this.date = new Date(date);
    this.category = category;
    this.seats = seats;
  }

  // Prototype method to check if event is upcoming and has seats
  checkAvailability() {
    const now = new Date();
    if (this.date < now) return false; // event is in past
    if (this.seats <= 0) return false; // no seats left
    return true;
  }

  // Register a user, reduce seat count, or throw error
  registerUser() {
    if (!this.checkAvailability()) {
      throw new Error(`Cannot register for "${this.name}": Event full or past.`);
    }
    this.seats--;
    console.log(`🎟️ Registered for "${this.name}". Seats left: ${this.seats}`);
  }

  // Print all properties using Object.entries()
  printDetails() {
    console.log(`Details for event "${this.name}":`);
    Object.entries(this).forEach(([key, value]) => {
      if (key === "date") {
        console.log(`  ${key}: ${value.toDateString()}`);
      } else {
        console.log(`  ${key}: ${value}`);
      }
    });
  }
}

// Sample events
const events = [
  new Event("Beach Cleanup", "2025-06-30", "Environment", 25),
  new Event("Food Drive", "2025-05-10", "Charity", 10), // past event
  new Event("Coding Bootcamp", "2025-06-28", "Education", 15),
  new Event("Tree Plantation", "2025-07-05", "Environment", 0), // full
];

// Function to list all events that are available
function listAvailableEvents(events) {
  console.log("\n✅ Available Events:");
  events.forEach(ev => {
    if (ev.checkAvailability()) {
      ev.printDetails();
      console.log("---");
    }
  });
}

// Function to register for an event by name
function registerForEvent(eventName) {
  const event = events.find(e => e.name === eventName);
  if (!event) {
    console.error(`❌ Event "${eventName}" not found.`);
    return;
  }
  try {
    event.registerUser();
  } catch (err) {
    console.error(`❌ ${err.message}`);
  }
}

// Show all available events
listAvailableEvents(events);

// Try registering users
registerForEvent("Beach Cleanup");   // success
registerForEvent("Tree Plantation"); // fail - full
registerForEvent("Food Drive");      // fail - past
registerForEvent("Coding Bootcamp"); // success

// Show updated events after registration
listAvailableEvents(events);
