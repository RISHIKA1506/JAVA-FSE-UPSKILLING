console.log("Welcome to the Community Portal");

window.onload = function () {
  alert("Page fully loaded. Welcome to the Community Portal!");

  // Sample list of events
  const events = [
    { name: "Beach Cleanup", date: "2025-06-30", seats: 25 },
    { name: "Food Drive", date: "2025-05-10", seats: 10 }, // Past event
    { name: "Tree Plantation", date: "2025-07-05", seats: 0 }, // Full
    { name: "Coding Bootcamp", date: "2025-06-28", seats: 15 }
  ];

  const today = new Date();

  console.log("📅 Upcoming Events with Available Seats:");

  // Loop through events using forEach
  events.forEach((event) => {
    const eventDate = new Date(event.date);

    // Check if event is in the future and has seats
    if (eventDate > today && event.seats > 0) {
      console.log(`✅ ${event.name} on ${event.date} — Seats: ${event.seats}`);

      // Simulate registration
      try {
        if (event.seats <= 0) {
          throw new Error("Registration failed: No seats available.");
        }

        event.seats--; // reduce one seat
        console.log(`🎟️ Registered for ${event.name}. Remaining Seats: ${event.seats}`);
      } catch (err) {
        console.error(`❌ Error for ${event.name}: ${err.message}`);
      }

    } else {
      console.log(`❌ ${event.name} is either full or already happened.`);
    }
  });
};
