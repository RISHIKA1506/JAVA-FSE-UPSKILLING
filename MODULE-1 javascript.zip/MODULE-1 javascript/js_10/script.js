console.log("Loading events asynchronously");

const loading = document.querySelector("#loading");
const container = document.querySelector("#events-container");

// Function using default parameter and destructuring
function displayEvent({ name, date, category, seats }, parent = container) {
  const card = document.createElement("div");
  card.style.border = "1px solid #aaa";
  card.style.padding = "10px";
  card.style.margin = "5px";

  card.innerHTML = `<strong>${name}</strong><br>
                    Date: ${date}<br>
                    Category: ${category}<br>
                    Seats: ${seats}`;

  parent.appendChild(card);
}

// Show loading
loading.style.display = "block";

// Fetch and display
fetch("events.json")
  .then(response => response.json())
  .then(data => {
    loading.style.display = "none";

    // Clone array using spread operator
    const allEvents = [...data];

    // Display all events (or you can filter by category)
    allEvents.forEach(event => displayEvent(event));
  })
  .catch(error => {
    loading.style.display = "none";
    container.textContent = "Error loading events: " + error.message;
  });
